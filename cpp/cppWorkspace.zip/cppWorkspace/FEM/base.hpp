/************************
     "
   '':''
  ___:____      |\/|
,'        `.    \  /
|  O        \___/  |
~^~^~^~^~^~^~^~^~^~^~^~^~
@author: τ
*************************/

#pragma once

#include <iostream>
#include <map>
#include <string>
#include <vector>

namespace DataStruct {

struct MeshInfo {
  int n_p;
  int n_cell;
  std::vector<double> nodeCoord;
  std::vector<double> jacobian;
  std::vector<double> invJ;
};

struct BaseFunc {
  std::vector<double> gaussPoint;
  std::vector<double> weight;
  std::vector<double> value;
  std::vector<double> gradValue;
};

} // namespace DataStruct

namespace Mesh {

void get_mesh_info(std::string fpath, int mesh_order,
                   const DataStruct::MeshInfo &mesh_info,
                   const DataStruct::BaseFunc &base_func);
} // namespace Mesh
