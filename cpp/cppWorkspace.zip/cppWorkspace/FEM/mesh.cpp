/************************
     "
   '':''
  ___:____      |\/|
,'        `.    \  /
|  O        \___/  |
~^~^~^~^~^~^~^~^~^~^~^~^~
@author: τ
*************************/

#include <base.hpp>
#include <gmsh.h>

void Mesh::get_mesh_info(std::string fpath, int mesh_order,
                         const DataStruct::MeshInfo &mesh_info,
                         const DataStruct::BaseFunc &base_func) {
  gmsh::initialize();
  gmsh::open(fpath);
  gmsh::model::mesh::createEdges();

  int elementType = gmsh::model::mesh::getElementType("Triangle", mesh_order);

  std::string elementName;
  int dim, order, numNodes, numPrimaryNodes;
  std::vector<double> localNodeCoord;

  gmsh::model::mesh::getElementProperties(elementType, elementName, dim, order,
                                          numNodes, localNodeCoord,
                                          numPrimaryNodes);

  std::vector<size_t> nodeTag;
  std::vector<double> nodeCoord;
  std::vector<double> paramCoord;
  gmsh::model::mesh::getNodes(nodeTag, nodeCoord, paramCoord);

  const std::vector<double> localCoord{1 / 3, 1 / 3, 1 / 3};
  std::vector<double> jacobians;
  std::vector<double> determ;
  std::vector<double> coord;

  gmsh::model::mesh::getJacobians(elementType, localCoord, jacobians, determ,
                                  coord);
}