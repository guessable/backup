/************************
     "
   '':''
  ___:____      |\/|
,'        `.    \  /
|  O        \___/  |
~^~^~^~^~^~^~^~^~^~^~^~^~
*************************/

#include "base.hpp"

using Tools::R;

Matrix DiffusionEquation::VertexCenter::assemble_stiffness_matrix() const {
  Matrix stiffness_matrix(n, n, arma::fill::zeros);

  for (const Face &fh : mesh.faces()) {
    Vec2d K{mesh.calc_face_centroid(fh)[0], mesh.calc_face_centroid(fh)[1]};
    Matrix Λ = problem.diffusive(K);

    int size_fv = 0;
    for (const Vertex &vh1 : mesh.fv_range(fh)) {
      size_fv += 1;
    }

    for (const Vertex &vh : mesh.fv_range(fh)) {
      int c = vh.idx();
      if (!mesh.is_boundary(vh)) {
        const Vertex &vh_prev = Tools::vertex_prev(mesh, fh, vh);
        const Vertex &vh_next = Tools::vertex_next(mesh, fh, vh);

        Vec2d v{mesh.point(vh)[0], mesh.point(vh)[1]};
        Vec2d v_prev{mesh.point(vh_prev)[0], mesh.point(vh_prev)[1]};
        Vec2d v_next{mesh.point(vh_next)[0], mesh.point(vh_next)[1]};

        Vec2d σ_prev = (v + v_prev) / 2;
        Vec2d σ_next = (v + v_next) / 2;

        Vec2d n_prev = R * (K - σ_prev) / arma::norm(σ_prev - K);
        Vec2d n_next = R * (σ_next - K) / arma::norm(K - σ_next);

        double α_prev =
            ((arma::norm(σ_prev - K) * n_prev.t() * Λ * R * (σ_prev - v)) /
             ((K - v).t() * R * (σ_prev - v)))[0];
        double β_prev =
            ((arma::norm(σ_prev - K) * n_prev.t() * Λ * R * (K - v)) /
             ((σ_prev - v).t() * R * (K - v)))[0];
        double α_next =
            ((arma::norm(σ_next - K) * n_next.t() * Λ * R * (σ_next - v)) /
             ((K - v).t() * R * (σ_next - v)))[0];
        double β_next =
            ((arma::norm(σ_next - K) * n_next.t() * Λ * R * (K - v)) /
             ((σ_next - v).t() * R * (K - v)))[0];

        int prev = vh_prev.idx(), next = vh_next.idx();

        stiffness_matrix(c, c) += α_prev + α_next + β_prev / 2 + β_next / 2;
        stiffness_matrix(c, prev) -= β_prev / 2;
        stiffness_matrix(c, next) -= β_next / 2;
        for (const Vertex &vh1 : mesh.fv_range(fh)) {
          int c1 = vh1.idx();
          stiffness_matrix(c, c1) -= (α_prev + α_next) / size_fv;
        }
      } else {
        stiffness_matrix(c, c) = 1; // wrong: stiffness_matrix += 1
      }
    }
  }
  return stiffness_matrix;
}

Vector DiffusionEquation::VertexCenter::assemble_source_term() const {
  Vector b(n, arma::fill::zeros);
  for (const Vertex &vh : mesh.vertices()) {
    int c = vh.idx();
    Vec2d v{mesh.point(vh)[0], mesh.point(vh)[1]};
    if (!mesh.is_boundary(vh)) {
      double b_temp = 0.0;
      for (const Face &vf : mesh.vf_range(vh)) {
        Vec2d K{mesh.calc_face_centroid(vf)[0], mesh.calc_face_centroid(vf)[1]};
        const Vertex &vh_prev = Tools::vertex_prev(mesh, vf, vh);
        const Vertex &vh_next = Tools::vertex_next(mesh, vf, vh);

        Vec2d v_prev{mesh.point(vh_prev)[0], mesh.point(vh_prev)[1]};
        Vec2d v_next{mesh.point(vh_next)[0], mesh.point(vh_next)[1]};

        Vec2d σ_prev = (v + v_prev) / 2;
        Vec2d σ_next = (v + v_next) / 2;

        Vec2d center = (v + σ_prev + σ_next + K) / 4;
        b_temp += problem.source(center) * (Tools::area(σ_prev, v, σ_next) +
                                            Tools::area(σ_prev, K, σ_next));
      }
      b[c] += b_temp;
    } else {
      b[c] += problem.solution(v);
    }
  }
  return b;
}
