/************************
     "
   '':''
  ___:____      |\/|
,'        `.    \  /
|  O        \___/  |
~^~^~^~^~^~^~^~^~^~^~^~^~
*************************/

#include <ranges>
#include <string>

#include "base.hpp"
#include "gflags/gflags.h"

using DiffusionEquation::Problem;
using DiffusionEquation::Scheme;
using DiffusionEquation::VertexCenter;

Vector solver(const Scheme &scheme, const Problem &problem) {
  Matrix A = scheme.assemble_stiffness_matrix();
  Vector b = scheme.assemble_source_term();
  Vector u_numerical = arma::solve(A, b);

  return u_numerical;
}

// args
DEFINE_int32(cases, 5, "case: 1-9");
DEFINE_string(mesh, "triangle_uniform", "mesh name");
DEFINE_int32(n_level, 5, "mesh level");

int main(int argc, char *argv[]) {
  // options
  gflags::ParseCommandLineFlags(&argc, &argv, true);

  // problem
  Problem problem = Problem(FLAGS_cases);

  // mesh
  std::string dir = "./meshes/";
  PolyMesh mesh;

  double max_error_up, L2_error_up, h1_error_up;
  float hemsh_up;

  // Info
  fmt::println("{:=<60}", "");
  fmt::println("mesh: {} | case: {}", FLAGS_mesh, FLAGS_cases);
  fmt::println("{0:<7}{1:<11}{4:<7}{2:<11}{4:<7}{3:<11}{4:<7}", "hmesh",
               "max_error", "L2_error", "h1_error", "ratio");
  // solve
  for (int level : std::ranges::iota_view(1, FLAGS_n_level + 1)) {
    std::string path = dir + FLAGS_mesh + "_" + std::to_string(level) + ".obj";
    if (!OpenMesh::IO::read_mesh(mesh, path)) {
      fmt::print("read error\n");
      exit(1);
    }
    float hmesh = 0.0;
    for (const auto &edge : mesh.edges()) {
      hmesh = std::max(hmesh, mesh.calc_edge_length(edge));
    }
    // scheme
    VertexCenter scheme = VertexCenter(problem, mesh);
    Vector u_num = solver(scheme, problem);

    // error
    double max_error{Tools::max_error(mesh, problem, u_num)},
        L2_error{Tools::L2_error(mesh, problem, u_num)},
        h1_error{Tools::h1_error(mesh, problem, u_num)};

    // R_α
    auto ratio = [&](double err_up, double err) {
      return log(err_up / err) / log(hemsh_up / hmesh);
    };
    double ratio_max{level > 1 ? ratio(max_error_up, max_error) : 0},
        ratio_L2{level > 1 ? ratio(L2_error_up, L2_error) : 0},
        ratio_h1{level > 1 ? ratio(h1_error_up, h1_error) : 0};
    fmt::println(
        "{0:<7.3f}{1:<11.3e}{2:<7.3f}{3:<11.3e}{4:<7.3f}{5:<11.3e}{6:<7."
        "3f}",
        hmesh, max_error, ratio_max, L2_error, ratio_L2, h1_error, ratio_h1);

    hemsh_up = hmesh;
    max_error_up = max_error, L2_error_up = L2_error, h1_error_up = h1_error;
  }
}
