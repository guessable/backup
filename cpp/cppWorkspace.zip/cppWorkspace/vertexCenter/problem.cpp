/************************
     "
   '':''
  ___:____      |\/|
,'        `.    \  /
|  O        \___/  |
~^~^~^~^~^~^~^~^~^~^~^~^~
*************************/

#include "base.hpp"

using Tools::π;

double DiffusionEquation::Problem::solution(const Vec2d &point) const {
  double x = point[0], y = point[1];
  if (cases == 1) {
    return x + y;
  } else if (cases == 2) {
    return x * x + y * y;
  } else if (cases == 3) {
    return pow(x, 3) + pow(y, 3);
  } else if (cases == 4) {
    return pow(x, 4) + pow(y, 4);
  } else if (cases == 5) {
    return exp(-x * x - y * y);
  } else if (cases == 6) {
    if (x <= 0.5) {
      return 14 * x + y;
    } else {
      return 4 * x + y + 5;
    }
  } else if (cases == 7) {
    double xx = 1.0 - x, yy = 1.0 - y;
    return 0.5 * (sin(xx * yy) / sin(1.0) + pow(xx, 3) * pow(yy, 2));
  } else if (cases == 8) {
    if (x <= 0.5) {
      return 1 - 2 * y * y + 4 * x * y + 6 * x + 2 * y;
    } else {
      return 3.25 - 2 * y * y + 3.5 * y + x * y + 1.5 * x;
    }
  } else if (cases == 9) {
    double c;
    if (y < 0.5) {
      if (x < 0.5) {
        c = 0.1;
      } else {
        c = 10.0;
      }
    } else {
      if (x < 0.5) {
        c = 0.01;
      } else {
        c = 100;
      }
    }
    return c * sin(2 * π * x) * sin(2 * π * y) + 12.0;
  }

  return x + y;
}

Mat2d DiffusionEquation::Problem::diffusive(const Vec2d &point) const {
  double x = point[0], y = point[1];
  if (cases == 1 || cases == 2 || cases == 3 || cases == 4 || cases == 5) {
    return Mat2d{{1, 0}, {0, 1}};
  } else if (cases == 6) {
    if (x <= 0.5) {
      return Mat2d{{3, 1}, {1, 3}};
    } else {
      return Mat2d{{10, 3}, {3, 10}};
    }
  } else if (cases == 7) {
    return Mat2d{{1.5, 0.5}, {0.5, 1.5}};
  } else if (cases == 8) {
    if (x <= 0.5) {
      return Mat2d{{1, 0}, {0, 1}};
    } else {
      return Mat2d{{4, 0}, {0, 4}};
    }
  } else if (cases == 9) {
    if (y < 0.5) {
      if (x < 0.5) {
        return Mat2d{{10, 0}, {0, 0.1}};
      } else {
        return Mat2d{{0.1, 0}, {0, 100}};
      }
    } else {
      if (x < 0.5) {
        return Mat2d{{100, 0}, {0, 0.1}};
      } else {
        return Mat2d{{0.01, 0}, {0, 10}};
      }
    }
  }

  return Mat2d{{1.0, 0}, {0, 1}};
}

double DiffusionEquation::Problem::source(const Vec2d &point) const {
  double x = point[0], y = point[1];
  if (cases == 1) {
    return 0.0;
  } else if (cases == 2) {
    return -4.0;
  } else if (cases == 3) {
    return -6 * x - 6 * y;
  } else if (cases == 4) {
    return -12 * x * x - 12 * y * y;
  } else if (cases == 5) {
    return -4 * (x * x + y * y - 1) * exp(-x * x - y * y);
  } else if (cases == 6) {
    return 0.0;
  } else if (cases == 7) {
    Mat2d K = diffusive(point);
    double kxx = K(0, 0), kxy = K(0, 1), kyy = K(1, 1);
    double xx = 1 - x, yy = 1 - y;
    double u_xx = -(yy * yy) * sin(xx * yy) / sin(1.0) + 6 * xx * yy * yy;
    double u_xy = -xx * yy * sin(xx * yy) / sin(1.0) + cos(xx * yy) / sin(1.0) +
                  6 * xx * xx * yy;
    double u_yy = -(xx * xx) * sin(xx * yy) / sin(1.0) + 2 * pow(xx, 3);
    return -0.5 * (kxx * u_xx + 2 * kxy * u_xy + kyy * u_yy);
  } else if (cases == 8) {
    Mat2d K = diffusive(point);
    double kxx = K(0, 0), kxy = K(0, 1), kyy = K(1, 1);
    double u_xx, u_xy, u_yy;
    if (x <= 0.5) {
      u_xx = 0.0, u_xy = 4.0, u_yy = -4.0;
    } else {
      u_xx = 0.0, u_xy = 1.0, u_yy = -4.0;
    }
    return -(kxx * u_xx + 2 * kxy * u_xy + kyy * u_yy);
  } else if (cases == 9) {
    Mat2d K = diffusive(point);
    double kxx = K(0, 0), kxy = K(0, 1), kyy = K(1, 1);
    double c;
    if (y < 0.5) {
      if (x < 0.5) {
        c = 0.1;
      } else {
        c = 10.0;
      }
    } else {
      if (x < 0.5) {
        c = 0.01;
      } else {
        c = 100;
      }
    }
    double u_xx = (-c * (4 * π * π) * sin(2 * π * x) * sin(2 * π * y));
    double u_xy = (c * (4 * π * π) * cos(2 * π * x) * cos(2 * π * y));
    double u_yy = (-c * (4 * π * π) * sin(2 * π * x) * sin(2 * π * y));
    return -(kxx * u_xx + 2 * kxy * u_xy + kyy * u_yy);
  }

  return 0.0;
}

Vec2d DiffusionEquation::Problem::grad(const Vec2d &point) const {
  double x = point[0], y = point[1];
  if (cases == 1) {
    return Vec2d{1, 1};
  } else if (cases == 2) {
    return Vec2d{2 * x, 2 * y};
  } else if (cases == 3) {
    return Vec2d{3 * x * x, 3 * y * y};
  } else if (cases == 4) {
    return Vec2d{4 * pow(x, 3), 4 * pow(y, 3)};
  } else if (cases == 5) {
    return Vec2d{-2 * x * exp(-x * x - y * y), -2 * y * exp(-x * x - y * y)};
  } else if (cases == 6) {
    double u_x, u_y;
    if (x <= 0.5) {
      u_x = 14, u_y = 1;
    } else {
      u_x = 4, u_y = 1;
    }
    return Vec2d{u_x, u_y};
  } else if (cases == 7) {
    double xx = 1.0 - x;
    double yy = 1.0 - y;

    double u_x = 0.5 * (-yy * cos(xx * yy) / sin(1.0) - 3 * xx * xx * yy * yy);
    double u_y = 0.5 * (-xx * cos(xx * yy) / sin(1.0) - 2 * pow(xx, 3) * yy);
    return Vec2d{u_x, u_y};
  } else if (cases == 8) {
    double u_x, u_y;
    if (x <= 0.5) {
      u_x = 4 * y + 6.0;
      u_y = -4 * y + 4 * x + 2.0;
    } else {
      u_x = y + 1.5;
      u_y = x - 4 * y + 3.5;
    }
    return Vec2d{u_x, u_y};
  } else if (cases == 9) {
    double c, u_x, u_y;
    if (y < 0.5) {
      if (x < 0.5) {
        c = 0.1;
      } else {
        c = 10;
      }
    } else {
      if (x < 0.5) {
        c = 0.01;
      } else {
        c = 100;
      }
    }
    u_x = c * 2 * π * cos(2 * π * x) * sin(2 * π * y);
    u_y = c * 2 * π * sin(2 * π * x) * cos(2 * π * y);
    return Vec2d{u_x, u_y};
  }

  return Vec2d{1, 1};
}
