/************************
     "
   '':''
  ___:____      |\/|
,'        `.    \  /
|  O        \___/  |
~^~^~^~^~^~^~^~^~^~^~^~^~
*************************/

#pragma once
#include <math.h>

#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/Mesh/PolyMesh_ArrayKernelT.hh>
#include <armadillo>
#include <numbers>

#include "fmt/core.h"

using Vec2d = arma::vec2;
using Mat2d = arma::mat22;
using Matrix = arma::mat;
using Vector = arma::vec;
using PolyMesh = OpenMesh::PolyMesh_ArrayKernelT<>;

using Face = OpenMesh::FaceHandle;
using Vertex = OpenMesh::VertexHandle;

namespace DiffusionEquation {
class Problem {
private:
  int cases;

public:
  Problem(int cases = 1) : cases(cases) { assert(cases <= 9); };
  double solution(const Vec2d &point) const;
  Mat2d diffusive(const Vec2d &point) const;
  double source(const Vec2d &point) const;
  Vec2d grad(const Vec2d &point) const;
};

class Scheme {
public:
  virtual Matrix assemble_stiffness_matrix() const = 0;
  virtual Vector assemble_source_term() const = 0;
};

class VertexCenter : public Scheme {
private:
  Problem problem;
  PolyMesh mesh;
  int n;

public:
  VertexCenter(const Problem &problem, const PolyMesh &mesh)
      : problem(problem), mesh(mesh) {
    n = mesh.n_vertices();
  };
  Matrix assemble_stiffness_matrix() const;
  Vector assemble_source_term() const;
};
} // namespace DiffusionEquation

namespace Tools {
const double π = std::numbers::pi;
const arma::mat22 R{{0.0, -1.0}, {1.0, 0.0}};
double area(const Vec2d &a, const Vec2d &b, const Vec2d &c);
Vertex vertex_prev(const PolyMesh &mesh, const Face &fh, const Vertex &vh);
Vertex vertex_next(const PolyMesh &mesh, const Face &fh, const Vertex &vh);
double max_error(const PolyMesh &mesh,
                 const DiffusionEquation::Problem &problem,
                 const Vector &u_numerical);
double L2_error(const PolyMesh &mesh, const DiffusionEquation::Problem &problem,
                const Vector &u_numerical);
double h1_error(const PolyMesh &mesh, const DiffusionEquation::Problem &problem,
                const Vector &u_numerical);
} // namespace Tools
