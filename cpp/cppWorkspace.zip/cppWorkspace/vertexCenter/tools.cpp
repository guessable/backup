/************************
     "
   '':''
  ___:____      |\/|
,'        `.    \  /
|  O        \___/  |
~^~^~^~^~^~^~^~^~^~^~^~^~
*************************/

#include "base.hpp"

double Tools::area(const Vec2d &a, const Vec2d &b, const Vec2d &c) {
  Vec2d ab = b - a, ac = c - a;
  return 0.5 * std::abs(ab[0] * ac[1] - ab[1] * ac[0]);
}

Vertex Tools::vertex_prev(const PolyMesh &mesh, const Face &fh,
                          const Vertex &vh) {
  for (const OpenMesh::HalfedgeHandle &heh : mesh.fh_range(fh)) {
    if (mesh.to_vertex_handle(heh) == vh) {
      return mesh.from_vertex_handle(heh);
    }
  }
  return vh;
}

Vertex Tools::vertex_next(const PolyMesh &mesh, const Face &fh,
                          const Vertex &vh) {
  for (const OpenMesh::HalfedgeHandle &heh : mesh.fh_range(fh)) {
    if (mesh.from_vertex_handle(heh) == vh) {
      return mesh.to_vertex_handle(heh);
    }
  }
  return vh;
}

double Tools::max_error(const PolyMesh &mesh,
                        const DiffusionEquation::Problem &problem,
                        const Vector &u_numerical) {
  double error = 0.0;
  for (const Vertex &vh : mesh.vertices()) {
    if (!mesh.is_boundary(vh)) {
      int c = vh.idx();
      Vec2d v = Vec2d{mesh.point(vh)[0], mesh.point(vh)[1]};
      double u_ref = problem.solution(v);
      double u_num = u_numerical[c];
      error = std::max(std::abs(u_ref - u_num), error);
    }
  }
  return error;
}

double Tools::L2_error(const PolyMesh &mesh,
                       const DiffusionEquation::Problem &problem,
                       const Vector &u_numerical) {
  double error = 0.0;
  for (const Vertex &vh : mesh.vertices()) {
    if (!mesh.is_boundary(vh)) {
      int c = vh.idx();
      Vec2d v = Vec2d{mesh.point(vh)[0], mesh.point(vh)[1]};
      double u_ref = problem.solution(v);
      double u_num = u_numerical[c];
      double volumn = 0;
      for (Face vf : mesh.vf_range(vh)) {
        Vec2d K{mesh.calc_face_centroid(vf)[0], mesh.calc_face_centroid(vf)[1]};
        const Vertex &vh_prev = Tools::vertex_prev(mesh, vf, vh);
        const Vertex &vh_next = Tools::vertex_next(mesh, vf, vh);

        Vec2d v_prev{mesh.point(vh_prev)[0], mesh.point(vh_prev)[1]};
        Vec2d v_next{mesh.point(vh_next)[0], mesh.point(vh_next)[1]};

        Vec2d σ_prev = (v + v_prev) / 2;
        Vec2d σ_next = (v + v_next) / 2;

        volumn +=
            Tools::area(σ_prev, v, σ_next) + Tools::area(σ_prev, K, σ_next);
      }
      error += pow(u_ref - u_num, 2) * volumn;
    }
  }
  return sqrt(error);
}

double Tools::h1_error(const PolyMesh &mesh,
                       const DiffusionEquation::Problem &problem,
                       const Vector &u_numerical) {
  double error = 0;
  arma::mat22 R{{0.0, -1.0}, {1.0, 0.0}};
  for (const Vertex &vh : mesh.vertices()) {
    if (!mesh.is_boundary(vh)) {
      Vec2d v = Vec2d{mesh.point(vh)[0], mesh.point(vh)[1]};
      for (const Face &vf : mesh.vf_range(vh)) {
        Vec2d K{mesh.calc_face_centroid(vf)[0], mesh.calc_face_centroid(vf)[1]};
        const Vertex &vh_prev = Tools::vertex_prev(mesh, vf, vh);
        const Vertex &vh_next = Tools::vertex_next(mesh, vf, vh);

        Vec2d v_prev{mesh.point(vh_prev)[0], mesh.point(vh_prev)[1]};
        Vec2d v_next{mesh.point(vh_next)[0], mesh.point(vh_next)[1]};

        Vec2d σ_prev = (v + v_prev) / 2;
        Vec2d σ_next = (v + v_next) / 2;

        int c = vh.idx(), prev = vh_prev.idx(), next = vh_next.idx();
        double u_k = 0;
        int size = 0;
        for (const Vertex &vh1 : mesh.fv_range(vf)) {
          u_k += u_numerical[vh1.idx()];
          size += 1;
        }

        Vec2d n_1 = R * (v - K);
        Vec2d n_2 = R * (σ_prev - σ_next);

        double area =
            Tools::area(σ_prev, v, σ_next) + Tools::area(σ_prev, K, σ_next);

        Vec2d u_grad = 1 / (2 * area) *
                       ((u_numerical[next] - u_numerical[prev]) / 2 * n_1 +
                        (u_numerical[c] - u_k / size) * n_2);
        Vec2d u_grad_ref = problem.grad((v + σ_prev + σ_next + K) / 4);

        error += area * pow(arma::norm(u_grad - u_grad_ref), 2);
      }
    }
  }
  return sqrt(error);
}
